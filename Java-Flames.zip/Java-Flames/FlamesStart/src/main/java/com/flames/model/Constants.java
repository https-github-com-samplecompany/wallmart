package com.flames.model;

public class Constants {
    public static String Flames = "FLAMES";
    public static String response = "response";

    public static String status_True = "true";
    public static String status_False = "false";
    public static String errorMsg = "FirstName and SecondName should not be empty";
}
